def meters_to_feet(meters):
    feet = round(meters / 0.3048, 2)
    return feet

def feet_to_meters(feet):
    meters = round(feet * 0.3048, 2)
    return meters